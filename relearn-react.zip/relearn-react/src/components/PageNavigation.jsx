import React from "react";
import { NavLink } from "react-router-dom";
import Logo from "./Logo";
import styles from "../styles/PageNav.module.css";


function PageNavigation() {
    return (
        <nav className={styles.nav}>
            <Logo />
            <ul>
                <li>
                    <NavLink to="/">Home</NavLink>
                </li>
                <li>
                    <NavLink to="/products">My Products</NavLink> <br />
                </li>
                <li>
                    <NavLink to="/pricing">My Prices</NavLink>
                </li>
                <li>
                    <NavLink to="/login" className={styles.ctaLink}>
                    Login
                    </NavLink>
                </li>
            </ul>
        </nav>
    );
}

export default PageNavigation;