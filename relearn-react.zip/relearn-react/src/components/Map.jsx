import React from 'react'

function Map() {
  return (
    <div>Map</div>
  )
}

export default Map