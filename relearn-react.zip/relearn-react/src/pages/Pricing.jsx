import React from "react";
import PageNavigation from "../components/PageNavigation";

function Pricing() {
    return (
        <div>
            <PageNavigation />
            <h1>Pricing</h1>
            <p>This is the pricing page</p>
        </div>
    )
}

export default Pricing;