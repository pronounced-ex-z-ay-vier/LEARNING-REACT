import React from "react";
import PageNavigation from "../components/PageNavigation";

function Products() {
    return (
        <div>
            <PageNavigation />
            <h1>Products</h1>
            <p>This is the products page</p>
        </div>
    )
}

export default Products;