import React from "react";
import PageNavigation from "../components/PageNavigation";

function PageNotFound() {
    return (
        <div>
            <PageNavigation />
            <h1>PageNotFound</h1>
            <p>This page aint available my guy</p>
        </div>
    )
}

export default PageNotFound;